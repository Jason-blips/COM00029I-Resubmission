#include <stdio.h>

int main(void) {
    for (int n = 1; n <= 200; n++) {
        int div3 = n % 3 == 0;
        int div5 = n % 5 == 0;
        
        if (div3 && div5) {
            printf("fizzbuzz\n");
        } else if (div3) {
            printf("fizz\n");
        } else if (div5) {
            printf("buzz\n");
        } else {
            printf("%d\n", n);
        }
    }
    return 0;
}

