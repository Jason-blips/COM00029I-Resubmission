import socket
import sys

def receive_file_udp(output_filename, listen_port, timeout=5):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    
    try:
        sock.bind(('', listen_port))
        sock.settimeout(timeout)
        
        print(f"Listening on port {listen_port}...")
        data, addr = sock.recvfrom(65535)
        
        print(f"Received {len(data)} bytes from {addr[0]}:{addr[1]}")
        
        with open(output_filename, 'wb') as f:
            f.write(data)
        
        print(f"File saved to: {output_filename}")
        
    except socket.timeout:
        print(f"Timeout: No data received after {timeout} seconds")
        sys.exit(1)
    except socket.error as e:
        print(f"Socket error: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
    finally:
        sock.close()

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("Usage: python3 UDPRX.py <output_filename> <listen_port>")
        sys.exit(1)
    
    output_filename = sys.argv[1]
    listen_port = int(sys.argv[2])
    
    receive_file_udp(output_filename, listen_port)


