import socket
import sys

def send_file_udp(filename, host, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    
    try:
        with open(filename, 'rb') as f:
            file_data = f.read()
        
        print(f"Sending {len(file_data)} bytes to {host}:{port}...")
        sock.sendto(file_data, (host, port))
        print("File sent successfully")
        
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found")
        sys.exit(1)
    except socket.error as e:
        print(f"Socket error: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
    finally:
        sock.close()

if __name__ == '__main__':
    if len(sys.argv) != 4:
        print("Usage: python3 UDPTX.py <filename> <host> <port>")
        sys.exit(1)
    
    filename = sys.argv[1]
    host = sys.argv[2]
    port = int(sys.argv[3])
    
    send_file_udp(filename, host, port)


