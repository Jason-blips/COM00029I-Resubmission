#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <pthread.h>
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Maximum string length */
#define MAX_STRING_LENGTH 80

/* Queue handle for string transmission */
static QueueHandle_t xStringQueue = NULL;

/* Character buffer for assembling strings in ISR */
static char isr_buffer[MAX_STRING_LENGTH + 1];
static int isr_buffer_index = 0;

/* High-priority printing task */
void vPrintTask(void *pvParameters) {
    char received_string[MAX_STRING_LENGTH + 1];
    
    for (;;) {
        if (xQueueReceive(xStringQueue, received_string, portMAX_DELAY) == pdTRUE) {
            printf("%s\n", received_string);
            fflush(stdout);
        }
    }
}

/* Interrupt Service Routine */
void vISR_CharacterReceived(char received_char) {
    char string_to_send[MAX_STRING_LENGTH + 1];
    int should_send = 0;
    
    /* Add character to buffer if space available */
    if (isr_buffer_index < MAX_STRING_LENGTH) {
        isr_buffer[isr_buffer_index++] = received_char;
    }
    
    /* Check if string should be sent */
    if (received_char == '\n' || isr_buffer_index >= MAX_STRING_LENGTH) {
        should_send = 1;
    }
    
    if (should_send) {
        /* Null-terminate and copy string */
        isr_buffer[isr_buffer_index] = '\0';
        strncpy(string_to_send, isr_buffer, MAX_STRING_LENGTH);
        string_to_send[MAX_STRING_LENGTH] = '\0';
        
        /* Send to queue from ISR (NULL for pxHigherPriorityTaskWoken in POSIX port) */
        xQueueSendToBackFromISR(xStringQueue, string_to_send, NULL);
        
        /* Reset buffer */
        isr_buffer_index = 0;
        isr_buffer[0] = '\0';
    }
}


int main(void) {
    xStringQueue = xQueueCreate(2, sizeof(char) * (MAX_STRING_LENGTH + 1));
    
    if (xStringQueue == NULL) {
        printf("Error: Failed to create queue\n");
        return 1;
    }
    
    xTaskCreate(vPrintTask, "PrintTask", configMINIMAL_STACK_SIZE * 2, NULL, 3, NULL);
    
    vTaskStartScheduler();
    
    return 0;
}



