#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BUFFER_SIZE 4096
#define PORT 8080
#define MAX_LINE_LENGTH 256

static void create_http_request(char* request, const char* path, const char* host) {
    snprintf(request, BUFFER_SIZE,
        "GET %s HTTP/1.1\r\n"
        "Host: %s\r\n"
        "Connection: close\r\n"
        "\r\n",
        path, host);
}

static int parse_http_status(const char* response) {
    int status_code = 0;
    if (sscanf(response, "HTTP/1.%*d %d", &status_code) == 1) {
        return status_code;
    }
    return 0;
}

static int extract_http_body(const char* response, size_t response_len, char* body, size_t* body_len) {
    const char* body_start = strstr(response, "\r\n\r\n");
    if (body_start == NULL) {
        return 0;
    }
    body_start += 4;
    size_t headers_len = body_start - response;
    *body_len = response_len - headers_len;
    memcpy(body, body_start, *body_len);
    return 1;
}

static int fetch_file(const char* server_ip, const char* path, char* buffer, size_t* buffer_len, int* status_code) {
    int sock;
    struct sockaddr_in server_addr;
    char request[BUFFER_SIZE];
    char response[BUFFER_SIZE * 2];
    size_t total_received = 0;
    ssize_t received;
    
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("socket");
        return -1;
    }
    
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    if (inet_aton(server_ip, &server_addr.sin_addr) == 0) {
        fprintf(stderr, "Invalid IP address: %s\n", server_ip);
        close(sock);
        return -1;
    }
    
    if (connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("connect");
        close(sock);
        return -1;
    }
    
    create_http_request(request, path, server_ip);
    if (send(sock, request, strlen(request), 0) < 0) {
        perror("send");
        close(sock);
        return -1;
    }
    
    total_received = 0;
    while (total_received < sizeof(response) - 1) {
        received = recv(sock, response + total_received, 
                       sizeof(response) - total_received - 1, 0);
        if (received < 0) {
            perror("recv");
            close(sock);
            return -1;
        }
        if (received == 0) {
            break;
        }
        total_received += (size_t)received;
    }
    
    response[total_received] = '\0';
    *status_code = parse_http_status(response);
    
    if (extract_http_body(response, total_received, buffer, buffer_len)) {
    } else {
        *buffer_len = 0;
    }
    
    close(sock);
    return 0;
}

static int save_file(const char* filename, const char* data, size_t data_len) {
    FILE* fp = fopen(filename, "wb");
    if (fp == NULL) {
        perror("fopen");
        return -1;
    }
    
    if (fwrite(data, 1, data_len, fp) != data_len) {
        perror("fwrite");
        fclose(fp);
        return -1;
    }
    
    fclose(fp);
    return 0;
}

static int process_manifest(const char* server_ip, const char* manifest_content, size_t manifest_len) {
    char line[MAX_LINE_LENGTH];
    const char* line_start = manifest_content;
    const char* line_end;
    char buffer[BUFFER_SIZE * 2];
    size_t buffer_len;
    int status_code;
    int success_count = 0;
    
    while (line_start < manifest_content + manifest_len) {
        line_end = strchr(line_start, '\n');
        if (line_end == NULL) {
            line_end = manifest_content + manifest_len;
        }
        
        size_t line_len = (size_t)(line_end - line_start);
        if (line_len > 0 && line_len < MAX_LINE_LENGTH) {
            memcpy(line, line_start, line_len);
            line[line_len] = '\0';
            
            while (line_len > 0 && (line[line_len - 1] == '\r' || 
                                    line[line_len - 1] == '\n' || 
                                    line[line_len - 1] == ' ' || 
                                    line[line_len - 1] == '\t')) {
                line_len--;
                line[line_len] = '\0';
            }
            
            if (line_len == 0) {
                line_start = line_end + 1;
                continue;
            }
            
            char file_path[512];
            if (line[0] == '/') {
                snprintf(file_path, sizeof(file_path), "%s", line);
            } else {
                snprintf(file_path, sizeof(file_path), "/%s", line);
            }
            
            buffer_len = 0;
            status_code = 0;
            if (fetch_file(server_ip, file_path, buffer, &buffer_len, &status_code) == 0) {
                if (status_code == 200) {
                    const char* filename = strrchr(file_path, '/');
                    if (filename == NULL) {
                        filename = file_path;
                    } else {
                        filename++;
                    }
                    
                    if (strlen(filename) == 0) {
                        filename = "index.html";
                    }
                    
                    if (save_file(filename, buffer, buffer_len) == 0) {
                        printf("Saved: %s (%zu bytes)\n", filename, buffer_len);
                        success_count++;
                    }
                }
            }
        }
        
        if (line_end >= manifest_content + manifest_len) {
            break;
        }
        line_start = line_end + 1;
    }
    
    return success_count;
}

int main(int argc, char* argv[]) {
    char manifest_buffer[BUFFER_SIZE * 2];
    size_t manifest_len;
    int status_code;
    
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <server_ip>\n", argv[0]);
        exit(1);
    }
    
    const char* server_ip = argv[1];
    
    manifest_len = 0;
    status_code = 0;
    
    if (fetch_file(server_ip, "/manifest", manifest_buffer, &manifest_len, &status_code) != 0) {
        fprintf(stderr, "Error: Failed to fetch manifest file\n");
        exit(1);
    }
    
    if (status_code != 200) {
        fprintf(stderr, "Error: Manifest file not found (status: %d)\n", status_code);
        exit(1);
    }
    
    if (process_manifest(server_ip, manifest_buffer, manifest_len) == 0) {
        fprintf(stderr, "Warning: No files were successfully fetched\n");
    }
    
    return 0;
}
