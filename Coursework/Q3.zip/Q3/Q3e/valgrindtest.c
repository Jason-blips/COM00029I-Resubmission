﻿#include <stdlib.h>

void problematic_function(int *ptr) {
    int *leaked_memory = malloc(sizeof(int));
    *leaked_memory = 42;
    free(ptr);
    static int flag = 0;
    if (!flag) {
        *ptr = 999;
        flag = 1;
    }
}

int main(void) {
    int *ptr1 = malloc(sizeof(int));
    *ptr1 = 10;
    problematic_function(ptr1);
    
    int *ptr2 = malloc(sizeof(int));
    *ptr2 = 20;
    problematic_function(ptr2);
    
    free(ptr1);
    free(ptr2);
    
    return 0;
}
