#!/usr/bin/env python3
"""
ntp.py
Capture broadcast NTP packets from Pi-1 and extract raw time value
Run on Pi-3 to display time as Unix time (seconds since Unix epoch)
"""

import socket
import struct
import time

NTP_PORT = 123
NTP_EPOCH_OFFSET = 2208988800

def parse_ntp_packet(data):
    """Parse NTP packet and extract timestamps"""
    if len(data) < 48:
        return None
    
    unpacked = struct.unpack('!BBBBIIIQQQQ', data[:48])
    
    flags = unpacked[0]
    stratum = unpacked[1]
    poll = unpacked[2]
    precision = unpacked[3]
    ref_timestamp = unpacked[7]
    orig_timestamp = unpacked[8]
    recv_timestamp = unpacked[9]
    trans_timestamp = unpacked[10]
    
    return {
        'flags': flags,
        'stratum': stratum,
        'poll': poll,
        'precision': precision,
        'ref_timestamp': ref_timestamp,
        'orig_timestamp': orig_timestamp,
        'recv_timestamp': recv_timestamp,
        'trans_timestamp': trans_timestamp,
        'raw_data': data
    }

def ntp_to_unix_time(ntp_timestamp):
    """Convert NTP timestamp to Unix time"""
    seconds = (ntp_timestamp >> 32) & 0xFFFFFFFF
    fraction = ntp_timestamp & 0xFFFFFFFF
    unix_seconds = seconds - NTP_EPOCH_OFFSET
    unix_time = unix_seconds + (fraction / (2**32))
    return unix_time, seconds, fraction

def capture_ntp_broadcast():
    """Capture broadcast NTP packets from Pi-1"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    
    try:
        sock.bind(('', NTP_PORT))
        print(f"Listening for NTP broadcast packets on port {NTP_PORT}...")
        print("Waiting for packets from Pi-1...")
        print()
    except OSError as e:
        if e.errno == 98 or "Address already in use" in str(e):
            print(f"Error: Port {NTP_PORT} is already in use")
            print("You may need to stop the NTP service: sudo systemctl stop ntp")
            print("Or run with sudo: sudo python3 ntp.py")
        else:
            print(f"Error binding to port {NTP_PORT}: {e}")
        return
    
    packet_count = 0
    
    try:
        while True:
            data, addr = sock.recvfrom(1024)
            packet_count += 1
            receive_time = time.time()
            
            print(f"=== Packet #{packet_count} from {addr[0]}:{addr[1]} ===")
            
            ntp_data = parse_ntp_packet(data)
            
            if ntp_data:
                trans_timestamp = ntp_data['trans_timestamp']
                unix_time, ntp_seconds, ntp_fraction = ntp_to_unix_time(trans_timestamp)
                
                print(f"Flags: 0x{ntp_data['flags']:02x}, Stratum: {ntp_data['stratum']}")
                print(f"Transmit Timestamp (64-bit): {trans_timestamp:016x}")
                print(f"  NTP Seconds: 0x{ntp_seconds:08x} = {ntp_seconds}")
                print(f"  NTP Fraction: 0x{ntp_fraction:08x} = {ntp_fraction}")
                print()
                print(f"Unix Time: {unix_time:.6f} seconds since Unix epoch")
                print(f"Human Readable: {time.ctime(unix_time)}")
                print()
                
                time_offset = unix_time - receive_time
                print(f"Time Offset: {time_offset:.6f} seconds")
                print(f"  (Server transmit time - Client receive time)")
                print()
                
                rtt_approx = receive_time - unix_time
                if rtt_approx >= 0:
                    print(f"RTT Approximation: {rtt_approx:.6f} seconds ({rtt_approx*1000:.2f} ms)")
                    print(f"  (Note: In broadcast mode, RTT is approximate)")
                else:
                    print(f"RTT Approximation: negative value (clock synchronization issue)")
                print()
                
                print("Raw Packet Data (first 48 bytes):")
                raw_hex = ' '.join(f'{b:02x}' for b in ntp_data['raw_data'][:48])
                for i in range(0, len(raw_hex), 48):
                    print(f"  {raw_hex[i:i+48]}")
                print()
                print("-" * 60)
                print()
                
                if packet_count >= 5:
                    print("Captured 5 packets. Press Ctrl+C to exit...")
                    break
            else:
                print("Failed to parse NTP packet")
                print(f"Packet length: {len(data)} bytes")
                print()
    
    except KeyboardInterrupt:
        print("\nStopped capturing.")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        sock.close()

if __name__ == '__main__':
    print("NTP Broadcast Packet Capture")
    print("=" * 60)
    print("Capturing broadcast NTP packets from Pi-1")
    print("Displaying time as Unix time (seconds since epoch)")
    print("=" * 60)
    print()
    capture_ntp_broadcast()
